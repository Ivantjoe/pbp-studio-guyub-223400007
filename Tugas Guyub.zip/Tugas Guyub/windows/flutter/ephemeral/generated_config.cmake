# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\src\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Dokumen Kuliah\\Semester 9\\Pemograman Berbasis Platfrom\\pbp-proyek-semeru-main\\pbp-proyek-semeru-main\\flutter_application" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\src\\flutter"
  "PROJECT_DIR=C:\\Dokumen Kuliah\\Semester 9\\Pemograman Berbasis Platfrom\\pbp-proyek-semeru-main\\pbp-proyek-semeru-main\\flutter_application"
  "FLUTTER_ROOT=C:\\src\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Dokumen Kuliah\\Semester 9\\Pemograman Berbasis Platfrom\\pbp-proyek-semeru-main\\pbp-proyek-semeru-main\\flutter_application\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Dokumen Kuliah\\Semester 9\\Pemograman Berbasis Platfrom\\pbp-proyek-semeru-main\\pbp-proyek-semeru-main\\flutter_application"
  "FLUTTER_TARGET=C:\\Dokumen Kuliah\\Semester 9\\Pemograman Berbasis Platfrom\\pbp-proyek-semeru-main\\pbp-proyek-semeru-main\\flutter_application\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9CVUlMRF9OQU1FPTEuMC4w,RkxVVFRFUl9CVUlMRF9OVU1CRVI9MQ==,RkxVVFRFUl9WRVJTSU9OPTMuNDcuNw==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049YWJhZjljNTIzNw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ZGViMjg3NDgxZQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMy41"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Dokumen Kuliah\\Semester 9\\Pemograman Berbasis Platfrom\\pbp-proyek-semeru-main\\pbp-proyek-semeru-main\\flutter_application\\.dart_tool\\package_config.json"
)
