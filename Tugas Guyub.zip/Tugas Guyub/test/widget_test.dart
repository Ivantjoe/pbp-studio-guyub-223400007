
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_1/main.dart';

void main() {
  testWidgets('Menampilkan daftar backlog', (WidgetTester tester) async {
    // Menjalankan aplikasi
    await tester.pumpWidget(
      const MaterialApp(
        home: LayarGuyub(),
      ),
    );

    // Memastikan judul halaman tampil
    expect(find.text('Layar Guyub'), findsOneWidget);

    // Memastikan item backlog tampil
    expect(find.text('Halaman menu roti'), findsOneWidget);
    expect(find.text('Form pesanan'), findsOneWidget);
    expect(
      find.text('Tombol pesan tidak aktif di Safari'),
      findsOneWidget,
    );

    // Memastikan status backlog tampil
    expect(find.text('Done'), findsOneWidget);
    expect(find.text('Review'), findsOneWidget);
    expect(find.text('In Progress'), findsOneWidget);
  });

  testWidgets('Menampilkan penanggung jawab yang belum ditentukan',
      (WidgetTester tester) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: LayarGuyub(),
      ),
    );

    expect(find.text('Belum ditentukan'), findsOneWidget);
  });
}
