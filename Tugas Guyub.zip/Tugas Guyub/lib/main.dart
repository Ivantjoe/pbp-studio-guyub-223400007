import 'package:flutter/material.dart';

void main() {
  runApp(const MaterialApp(home: LayarGuyub()));
}

class ItemBacklog {
  final String kunci;
  final String judul;
  final String jenis;
  final int poin;
  final String status;
  final String? penanggungJawab;

  const ItemBacklog(
    this.kunci,
    this.judul,
    this.jenis,
    this.poin,
    this.status,
    this.penanggungJawab,
  );
}

class LayarGuyub extends StatelessWidget {
  const LayarGuyub({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Layar Guyub')),
      body: ListView.builder(
        itemCount: daftarItem.length,
        itemBuilder: (context, i) {
          final item = daftarItem[i];
          return Padding(
            padding: const EdgeInsets.all(8),
            child: ListTile(
              tileColor: Colors.blue,
              title: Text(item.judul),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.kunci),
                  Text(item.penanggungJawab ?? 'Belum ditentukan'),
                ],
              ),
              trailing: Text(item.status),
            ),
          );
        },
      ),
    );
  }
}

const daftarItem = [
  ItemBacklog('GYB-001', 'Halaman menu roti', 'story', 5, 'Done', 'Sekar'),
  ItemBacklog('GYB-002', 'Form pesanan', 'story', 5, 'Review', 'Bayu'),
  ItemBacklog(
    'GYB-003',
    'Tombol pesan tidak aktif di Safari',
    'bug',
    2,
    'In Progress',
    'Dimas',
  ),
  ItemBacklog(
    'GYB-004',
    'Ongkir dihitung per kecamatan',
    'story',
    3,
    'To Do',
    'Bayu',
  ),
  ItemBacklog('GYB-005', 'Foto produk lambat dimuat', 'bug', 2, 'To Do', null),
];

class DaftarKartu extends StatelessWidget {
  const DaftarKartu({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Daftar Kartu')),
      body: const Center(child: Text('Ini adalah halaman Daftar Kartu.')),
    );
  }
}